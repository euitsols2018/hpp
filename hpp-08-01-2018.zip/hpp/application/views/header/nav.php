		<nav class="navbar navbar-default ">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand logo_hpp" href="<?= SITE_URL;?>"><img src="<?= SITE_URL;?>assets/img/logo.png" alt=""></a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse yamm" id="navigation">
                    <!--<div class="button navbar-right">
                        <button class="navbar-btn nav-button wow bounceInRight login" onclick=" window.open('<?= SITE_URL;?>login/')" data-wow-delay="0.45s">Login</button>
                        <button class="navbar-btn nav-button wow fadeInRight" onclick="window.open('<?= SITE_URL;?>join/')" data-wow-delay="0.48s">Join</button>
                    </div>-->
					<div class="button navbar-right seperate_border_nav">
                        <a class="navbar-btn nav-button wow bounceInRight login" data-wow-delay="0.45s" href="<?= SITE_URL;?>login/">Login</a>
                        <?php
						$other_user_type 	= $this->user->any_where(array('TYPE_STATUS' => 'Active', 'TYPE_VIEW' => 'Other'), 'mt_s_user_type');
						$otherID 			= $other_user_type[0]['USER_TYPE_ID'];
						$navOther = $this->user->any_where(array('NAV_TYPE' => 'RightNav', 'USER_TYPE_ID' => $otherID, 'NAV_STATUS' => 'Active'), 'mt_nav_access');
						if(is_array($navOther) AND sizeof($navOther) > 0){
						?>
						
						<a class="navbar-btn nav-button wow fadeInRight join" href="<?= SITE_URL;?><?= $navOther[0]['NAV_URL']?>/" data-wow-delay="0.48s"><?= $navOther[0]['NAV_NAME']?></a>
					   <?php
						}
					   ?>
				   </div>
                    <ul class="main-nav nav navbar-nav navbar-right">
                        <li class="dropdown ymm-sw " data-wow-delay="0.1s">
                            <a href="<?= SITE_URL;?>" class="active" data-delay="200">Home </a>
                        </li>
						<?php
						$navMain = $this->user->any_where(array('NAV_TYPE' => 'Other', 'USER_TYPE_ID' => $otherID, 'NAV_STATUS' => 'Active'), 'mt_nav_access');
						$i = 0.2;
						if(is_array($navMain) AND sizeof($navMain) > 0){
							foreach($navMain AS $key=>$value):
						?>
							<li class="wow fadeInDown" data-wow-delay="<?= $i;?>s"><a class="" href="<?= SITE_URL;?><?= $value['NAV_URL']?>/"><?= $value['NAV_NAME']?></a></li>
                        
						<?php
						$i+=0.1;
						endforeach;
						}
					   ?>
                        <!--<li class="wow fadeInDown" data-wow-delay="0.3s"><a class="join_nav" href="<?= SITE_URL;?>sell/">Sell</a></li> -->
                        <!--<li class="dropdown yamm-fw" data-wow-delay="0.4s">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="200">Template <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li>
                                    <div class="yamm-content">
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <h5>Home pages</h5>
                                                <ul>
                                                    <li>
                                                        <a href="index.html">Home Style 1</a>
                                                    </li>
                                                    <li>
                                                        <a href="index-2.html">Home Style 2</a>
                                                    </li>
                                                    <li>
                                                        <a href="index-3.html">Home Style 3</a>
                                                    </li>
                                                    <li>
                                                        <a href="index-4.html">Home Style 4</a>
                                                    </li>
                                                    <li>
                                                        <a href="index-5.html">Home Style 5</a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="col-sm-3">
                                                <h5>Pages and blog</h5>
                                                <ul>
                                                    <li><a href="blog.html">Blog listing</a>  </li>
                                                    <li><a href="single.html">Blog Post (full)</a>  </li>
                                                    <li><a href="single-right.html">Blog Post (Right)</a>  </li>
                                                    <li><a href="single-left.html">Blog Post (left)</a>  </li>
                                                    <li><a href="contact.html">Contact style (1)</a> </li>
                                                    <li><a href="contact-3.html">Contact style (2)</a> </li>
                                                    <li><a href="contact_3.html">Contact style (3)</a> </li>
                                                    <li><a href="faq.html">FAQ page</a> </li> 
                                                    <li><a href="404.html">404 page</a>  </li>
                                                </ul>
                                            </div>
                                            <div class="col-sm-3">
                                                <h5>Property</h5>
                                                <ul>
                                                    <li><a href="property-1.html">Property pages style (1)</a> </li>
                                                    <li><a href="property-2.html">Property pages style (2)</a> </li>
                                                    <li><a href="property-3.html">Property pages style (3)</a> </li>
                                                </ul>

                                                <h5>Properties list</h5>
                                                <ul>
                                                    <li><a href="properties.html">Properties list style (1)</a> </li> 
                                                    <li><a href="properties-2.html">Properties list style (2)</a> </li> 
                                                    <li><a href="properties-3.html">Properties list style (3)</a> </li> 
                                                </ul>                                               
                                            </div>
                                            <div class="col-sm-3">
                                                <h5>Property process</h5>
                                                <ul> 
                                                    <li><a href="submit-property.html">Submit - step 1</a> </li>
                                                    <li><a href="submit-property.html">Submit - step 2</a> </li>
                                                    <li><a href="submit-property.html">Submit - step 3</a> </li> 
                                                </ul>
                                                <h5>User account</h5>
                                                <ul>
                                                    <li><a href="register.html">Register / login</a>   </li>
                                                    <li><a href="user-properties.html">Your properties</a>  </li>
                                                    <li><a href="submit-property.html">Submit property</a>  </li>
                                                    <li><a href="change-password.html">Change password</a> </li>
                                                    <li><a href="user-profile.html">Your profile</a>  </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </li>
                            </ul>
                        </li>

                        <li class="wow fadeInDown" data-wow-delay="0.5s"><a href="<?= SITE_URL;?>contact">Contact</a></li>-->
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
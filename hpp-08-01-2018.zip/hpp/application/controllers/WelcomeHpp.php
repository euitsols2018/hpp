<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class WelcomeHpp extends HPP_Controller {

    public function __construct(){
		parent::__construct();
		
	}
	
	
	public function index()
	{
		
		$data = array();
		$data['title'] = 'Welcome hot price property';
		
		$data['main_content']	= $this->load->view('page_templates/home_content', $data, true);
		$this->load->view('master', $data);
		
	}
	
	/**contact us page**/
	public function contactUs()
	{
		$data = array();
		$data['title'] = 'Contact us | HPP';
		
		$data['main_content']	= $this->load->view('page_templates/contact_content', $data, true);
		$this->load->view('master', $data);		
	}
	
	
	/**contact us page**/
	public function faqPage()
	{
		$data = array();
		$data['title'] = 'FAQ | HPP';
		$data['main_content']	= $this->load->view('page_templates/faq_content', $data, true);
		$this->load->view('master', $data);
	}
	
	
	
	
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PropertyControl extends HPP_Controller {


	function __construct(){
		parent::__construct();
		
	}
	
	public function index()
	{
		
		$data = array();
		$data['title'] = 'Welcome hot price property';
		
		$userID = $this->session->userData('userID');
		$logged_in = $this->session->userData('logged_in');
		if($userID > 0 AND $logged_in == TRUE){
		
		}
		$data['main_content']	= $this->load->view('page_templates/home_content', $data, true);
		$this->load->view('master', $data);		
	}
	
	/**Add new property**/
	public function add_property()
	{
		$data = array();
		$data['title'] = 'Add property | HPP';
		$userID = $this->session->userData('userID');
		$logged_in = $this->session->userData('logged_in');
		if($userID > 0 AND $logged_in == TRUE){
			if($this->hpp_url_check('sell', 'nav') > 0){
				
				$data['property_type']  = $this->any_where(array('PROPERTY_TYPE_STATUS' => 'Active'), 'mt_p_property_type');
				
				$type = isset($_GET['type']) ? $_GET['type'] : '0';
				$checkType = $this->any_where_count(array('PROPERTY_TYPE_STATUS' => 'Active', 'PROPERTY_TYPE_ID' => $type), 'mt_p_property_type', 'PROPERTY_TYPE_ID');
				if($checkType > 0){
					$data['type'] = $type;
					$data['dynamic_filed']  = $this->user->property_fileld($data['type']);
					
				}else{
					$data['type'] = 0;
					$data['dynamic_filed'] = array();
				}
				
				//print_r($data['dynamic_filed']);
				
				$data['main_content']	= $this->load->view('page_templates/property/add_property', $data, true);
			}else{
				$data['main_content']	= $this->load->view('errors/errors_page', $data, true);
			}
			
			
		}else{
			redirect(SITE_URL.'login?page=sell');
		}
		
		
		$this->load->view('master', $data);
		
	}
	
	
	/**property search by type**/
	public function searchProperty($type='buy')
	{
		$data = array();
		$data['title'] = 'Property search by '.$type.' | HPP';
		$data['type'] = $type;
		
		$data['main_content']	= $this->load->view('page_templates/property/property_search', $data, true);
		
		$this->load->view('master', $data);
	}
	
	
	
}

/**sign up form validation start**/

jQuery(document).ready(function(){
	
	/** validation for user sign up form**/
	$("#user_signup_form").validate({
		rules: {
			full_name:{
				required: true,
				minlength:4
			},
			mobile_no: {
				required: true,
				minlength:9
			},
			email_address: {
				required: true,
				email: true
			},
            rel_password: {
				 required: true,
				 minlength: 8
             },
            con_password: {
				 required: true,
				 minlength: 8,
				 equalTo: "#rel_password"
             }
			
			
		},
		
		messages: {
			full_name: {
				required: "Please enter name",
				minlength: "Full name should be min 4 chars"
			},
			mobile_no: {
				required: "Please enter your mobile no",
				minlength: "Mobile no should be min 9 chars"
			},
			email_address: {
				required: "Please enter your email address",
				email: "Please enter a valid email address"
			},
             rel_password: {
				 required: "Please provide a password",
				 minlength: "Your password must be at least 8 characters long"
             },
             con_password: {
				 required: "Please provide a password",
				 minlength: "Your password must be at least 8 characters long",
				 equalTo: "Please enter the same password as above"
             }
		}
	});
	
	
	/** validation for user login form**/
	$("#user_login_form").validate({
		rules:{
			login_email: {
				required: true,
				email: true
			},
            login_password: {
				 required: true,
				 minlength: 8
             },
		},
		messages:{
			login_email: {
				required: "Please enter your email address",
				email: "Please enter a valid email address"
			},
            login_password: {
				required: "Please provide a password",
				minlength: "Your password must be at least 8 characters long"
            }
		}
		
	});
	
	
	/** validation for add new property form**/
	$("#property_form").validate({
		rules:{
			propertyname: {
				required: true
			},
            propertyprice: {
				 required: true,
				 minlength: 2
             },
			location_name:{
				required: true
			},
			discrition:{
				required: true
			}
		},
		messages:{
			propertyname: {
				required: "Please enter property name"
			},
            propertyprice: {
				required: "Please property price",
				minlength: "Your price very lowest"
            },
			location_name:{
				required: "Location of property "
			},
			discrition:{
				required: "Enter your property description "
			}
		}
		
	});
	
	
	
})





/***Add filed option***/
function addMilestone(id){
	var row = id+1;
	var check = $("#headding__"+id).val();
	var price = $("#value__"+id).val();
	if(check.length > 3){
		if(price.length > 0){
			var filed ='';
				filed += '<div class="form-group" id="table__'+row+'"> <div class="form-row"> <div class="col-md-4">';
				filed += '<label for="exampleInputName"><b>Title '+row+': </b></label>';
				filed += '<input class="form-control" id="headding__'+row+'" name="headding[]" type="text" value=""  placeholder="Enter title '+row+'">';
				filed += '</div> <div class="col-md-6" id="value_remove__'+row+'"> <label for="exampleInputName"> Information '+row+': </label><input class="form-control" id="value__'+row+'" name="value[]" type="text" aria-describedby="nameHelp" value="" required="" placeholder="Enter Information '+row+'"></div>';
				//filed += '<div class="col-md-3" id="date_remove__'+row+'"> <label for="exampleInputName"> date '+row+': </label><input class="form-control" id="endDate" name="date[]"  type="date" value="" required="" placeholder="Enter date "></div>';
				filed += '<div class="col-md-1" id="button_remove__'+row+'"> <span class="fa fa-plus class_add" onclick="addMilestone('+row+')"></span> </div>';
				filed += '</div> </div>';
			var remove = '<span class="fa fa-close class_add class_remove" onclick="removeMilestone('+id+')"></span>';
			$("#button_remove__"+id).html(remove);
			
			$("#main_div").append(filed);
			$("#headding__"+row).focus();
		}else{
			$("#value__"+id).focus();
		}
	}else{
		$("#headding__"+id).focus();
	}
}


function removeMilestone(id){
	$("#table__"+id).html('');
}

/***Add filed option end***/

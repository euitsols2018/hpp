function select_type(id){
	
	$(".lavel").attr("style","border-color:#ccc;");
	$("#lavel__"+id).attr("style","border-color:#FDC600;");
	$("input[id='account_for__"+id+"']:checked");
	//alert(id);
	if(id == 4){
		$("#name_for_company").html('<b>Company Name</b>');
		$("#gender_show").css({"display":"none"});
	}else{
		$("#name_for_company").html('<b>Full Name</b>');
		$("#gender_show").css({"display":"block"});
	}
}

$(function(){
	var leb = $("input[name='account_for']:checked").val();
	select_type(leb);
	//alert(leb);
})

function removeChar(item)
{ 
	var val = item.value;
	val = val.replace(/[^0-9,.]/g, "");  
	if (val == ' '){val = ''};   
	item.value=val;
}
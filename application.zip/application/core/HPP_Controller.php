<?php
defined('BASEPATH') OR exit('No direct script access allowed');

 class HPP_Controller extends CI_Controller {
    var $CI;
    public $hpp_select = '*';
    public $hpp_table = '';
    public $hpp_order_column = '';
    public $hpp_order = '';
    public $hpp_limit = '';
    public $hpp_offset = '';
    public $hpp_query = array();
	
	public $conpanyID = '0';
    public $account_for = '0';
    public $account_type = '0';
    
	public function __construct() {
       parent::__construct();
	   //$this->CI =& get_instance();
	   $newdata = array('companyID' => 1, 'account_for' => 3, 'account_type' => 1);
	   $this->session->set_userdata($newdata);
	   
	   $this->conpanyID = $this->session->userData('companyID');
	   $this->account_for = $this->session->userData('account_for');
	   $this->account_type = $this->session->userData('account_type');
    }

	public function hpp_role($query=array()){		
		$this->db->select($this->hpp_select);
		if(is_array($query) AND sizeof($query) > 0){
			$query['COMPANY_ID'] = $this->conpanyID;
			$this->hpp_query = $query;									
		}
		$this->hpp_table = 'mt_s_user_role';
		$this->db->where($this->hpp_query);
		if (strlen($this->hpp_order_column) > 0){
            $this->db->order_by($this->hpp_order_column, $this->hpp_order);
        }
        if (strlen($this->hpp_limit) > 0){
            $this->db->limit($this->hpp_limit, $this->hpp_offset);
        }
		$results = $this->db->get($this->hpp_table);
		$result = $results->result_array();
		return $result;
	}
	
	public function hpp_user_type($query=array()){
		
		$this->db->select($this->hpp_select);
		if(is_array($query) AND sizeof($query) > 0){
			$query['COMPANY_ID'] = $this->conpanyID;
			$this->hpp_query = $query;			
		}
		$this->hpp_table = 'mt_s_user_type';
		$this->db->where($this->hpp_query);
		if (strlen($this->hpp_order_column) > 0){
            $this->db->order_by($this->hpp_order_column, $this->hpp_order);
        }
        if (strlen($this->hpp_limit) > 0){
            $this->db->limit($this->hpp_limit, $this->hpp_offset);
        }
		$results = $this->db->get($this->hpp_table);
		$result = $results->result_array();
		return $result;
	}
	
	public function any_where($query=array(), $table=''){
		if(strlen($table) > 0){
			$this->hpp_table = $table;
		}
		if(is_array($query) AND sizeof($query) > 0){
			$query['COMPANY_ID'] = $this->conpanyID;
			$this->hpp_query = $query;			
		}
		$this->db->where($this->hpp_query);
		$results = $this->db->get($this->hpp_table)->result_array();
		return $results;
	}
	
	public function any_where_count($query=array(), $table='', $count=''){
		if(strlen($count) > 0){
			$this->hpp_select = 'COUNT('.$count.') AS result';
			$this->db->select($this->hpp_select);
		}
		if(strlen($table) > 0){
			$this->hpp_table = $table;
		}
		if(is_array($query) AND sizeof($query) > 0){
			$query['COMPANY_ID'] = $this->conpanyID;
			$this->hpp_query = $query;			
		}
		$this->db->where($this->hpp_query);
		$results = $this->db->get($this->hpp_table)->result_array();
		return $results[0]['result'];
	}
	
	public function hpp_gender(){
		return array('Male' => 'Male', 'FeMale' => 'Female', 'Other' => 'Other');
	}
	
	public function hpp_url_check($page='', $type='page'){
		
		$userType 				= $this->session->userData('userType');
		$roleId 				= $this->session->userData('roleId');
		$userID 				= $this->session->userData('userID');						
		$access 				= $this->session->userData('access');						
		$logged_in 				= $this->session->userData('logged_in');
		
		if(strlen($page) > 0 AND $userID > 0 AND $logged_in == TRUE){
			if($type == 'nav'){
				$search 	= "SELECT * 
											FROM
													mt_nav_access AS page									
											INNER JOIN 
													mt_s_user_type AS type									
											ON 		page.USER_TYPE_ID = type.USER_TYPE_ID
											WHERE 	
													page.USER_TYPE_ID = ".$userType."
													AND page.NAV_URL = '".$page."'
													AND page.NAV_STATUS = 'Active'
													AND page.COMPANY_ID = ".$this->conpanyID."
									";
			}else{
				if($access == 'Parent'){
					$other_user_type 		= $this->user->any_where(array('TYPE_STATUS' => 'Active', 'TYPE_VIEW' => 'Other'), 'mt_s_user_type');
					$otherTypeID 			= $other_user_type[0]['USER_TYPE_ID'];
					
					$other_role_type 		= $this->user->any_where(array('ROLE_STATUS' => 'Active', 'ROLE_TYPE' => 'Other'), 'mt_s_user_role');
					$otherRoleID 			= $other_role_type[0]['ROLE_ID'];
					$search 	= "SELECT * 
											FROM
													mt_pg_page_name AS page									
											INNER JOIN 
													mt_s_user_type AS type									
											ON 		page.USER_TYPE_ID = type.USER_TYPE_ID
											INNER JOIN 
													mt_s_user_role AS role									
											ON 		page.ROLE_ID = role.ROLE_ID
											WHERE 	
													(page.USER_TYPE_ID = ".$userType."
													OR page.USER_TYPE_ID = ".$otherTypeID.")
													AND (page.ROLE_ID = ".$roleId."
													OR page.ROLE_ID = ".$otherRoleID.")
													AND page.PAGE_URL = '".$page."'
													AND page.PAGE_STATUS = 'Active'
													AND page.COMPANY_ID = ".$this->conpanyID."
									";
								
				}else{
					$search 	= "SELECT * 
										FROM
												mt_pg_page_name AS page									
										INNER JOIN 
												mt_pg_page_access AS access									
										ON 		page.PAGE_ID = access.PAGE_ID AND access.USER_ID = ".$userID."
										WHERE
												page.COMPANY_ID = ".$this->conpanyID."
												AND AND page.PAGE_URL = '".$page."'
												AND page.PAGE_STATUS = 'Active'
								";
								
				}
				
			}
			
			$query = $this->db->query($search);
			$count = $query->num_rows();
			return $count;
		}
	}
	
}

?>
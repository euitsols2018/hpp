<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginControll extends HPP_Controller {


	function __construct(){
		parent::__construct();	
		
	}
	
	public function index()
	{
		$data = array();
		$data['title'] 			= 'Login | HPP';
		$data['massege'] 		= '';
		$data['account_for'] 	= $this->account_for;
		$data['account_type'] 	= $this->account_type;
		$data['full_name'] 		= '';
		$data['mobile_no'] 		= '';
		$data['gender'] 		= 'Male';
		$data['email_address'] 	= '';
		$data['rel_password'] 	= '';
		$data['con_password'] 	= '';
		
		$data['role'] 			= $this->hpp_role(['ROLE_TYPE' => 'User', 'ROLE_STATUS =' => 'Active']);
		$data['user_type'] 		= $this->hpp_user_type(['TYPE_STATUS =' => 'Active', 'TYPE_VIEW =' => 'Show']);
		
		if(isset($_POST['user_signup'])){
			
			$insert 		= array();
			$insert_de 		= array();
			$insert_con 	= array();
			
			$insert['USER_NAME'] 	 = $this->input->post('full_name');
			//$insert['USER_LOG_NAME'] = substr( str_replace("_", "", $insert['USER_NAME']), 0,10).substr(time(), 4, 6);
			$insert['USER_LOG_NAME'] = time();
			$insert['EMAIL_ADDRESS'] = $this->input->post('email_address');
			$insert['PASS_USER'] 	 = 	md5($this->input->post('rel_password'));
			$insert['COMPANY_ID'] 	 = 	$this->conpanyID;
			$insert['ROLE_ID'] 	 	 = 	$this->input->post('account_for');
			$insert['USER_TYPE_ID']  = 	$this->input->post('account_type');
			$insert['ACCESS_TYPE']   = 'Parent';
			$insert['ENT_DATE'] 	 = date("Y-m-d");
			$insert['USER_STATUS']   = 'Pending';
			
			/*$valid = $this->Users->valitation(array(
												'text' => array( 'massage' => 'Please enter name', 'data' => $this->input->post('full_name'), 'then' => 1),
												'email' => array( 'massage' => 'Invalid email address', 'data' => $this->input->post('email_address')),
												'size' => array( 'massage' => 'Password must be 8 char', 'data' => $this->input->post('rel_password')),
												'equelTo' => array( 'massage' => 'Password don\'t match', 'data' => $this->input->post('rel_password'), 'with' => $this->input->post('con_password')),
												'max' => array( 'massage' => 'Please choose for account', 'data' => $this->input->post('account_for'), 'then' => 0),
												'max' => array( 'massage' => 'Please select account type', 'data' => $this->input->post('account_type'), 'then' => 0),
												)
											);
			if($valid != 11){
				echo $valid; exit;
			}
			*/
			$login_check = $this->any_where_count(array('EMAIL_ADDRESS' => $this->input->post('email_address'), 'USER_TYPE_ID' => $this->input->post('account_type')), 's_user_info', 'EMAIL_ADDRESS');
			if($login_check == 0){
				if($this->db->insert('s_user_info', $insert)){
					$userID_ge = $this->db->insert_id(); 
					$contact = $this->any_where(array('CONTACT_NAME' => 'Phone'), 'mt_c_contact_type');
					if(is_array($contact) AND sizeof($contact) > 0){
						$insert_con['CONTACT_NAME'] 	= $this->input->post('mobile_no');
						$insert_con['CONTACT_TYPE_ID']  = $contact[0]['CONTACT_TYPE_ID'];
						$insert_con['USER_ID'] 			= $userID_ge;
						$insert_con['COMPANY_ID'] 		= $this->conpanyID;
						$insert_con['ENT_DATE'] 		= date("Y-m-d");
						$insert_con['CONTACT_STATUS']   = 'Active';
						$this->db->insert('c_contact_info', $insert_con);
					}
					
					$insert_de['FULL_NAME'] 	= $this->input->post('full_name');
					$insert_de['GENTER'] 		= $this->input->post('gender');
					$insert_de['USER_ID'] 		= $userID_ge;
					$insert_de['COMPANY_ID'] 	= $this->conpanyID;
					$insert_de['ENT_DATE'] 		= date("Y-m-d");
					$insert_de['DETAILS_STATUS'] = 'Active';
					if($this->db->insert('s_user_details_info', $insert_de)){
						$data['massege'] = '<span class="success">Successfully create your account</span>';
					}else{
						$data['massege'] = '<span class="error">System Error</span>';
					}
				}
			}else{
				$data['massege'] = '<span class="error">Sorry! already have a account</span>';
			}
			
			$data['account_for'] 		= $insert['ROLE_ID'];
			$data['account_type'] 		= $insert['USER_TYPE_ID'];
			$data['full_name'] 			= $insert['USER_NAME'];
			$data['mobile_no'] 			= $this->input->post('mobile_no');
			$data['gender'] 			= $this->input->post('gender');
			$data['email_address'] 		= $insert['EMAIL_ADDRESS'];
			$data['rel_password'] 		= $this->input->post('rel_password');
			$data['con_password'] 		= $this->input->post('con_password');
			
		}
		$page = isset($_GET['page']) ? $_GET['page'] : 'profile';
		//echo 	$page;
		$data['MSG'] = '';
		$data['ACTION'] = $page;
		if(isset($_POST['user_login'])){
			$username 		= $this->input->post('login_email');
			$password 		= md5($this->input->post('login_password'));
			$account_login  = $this->input->post('account_login');
			
			if(strlen($username) > 0 AND strlen($password) > 0 AND $account_login > 0){
				$query = $this->db->query("SELECT * FROM s_user_info as user LEFT JOIN s_user_details_info as per ON user.USER_ID = per.USER_ID WHERE (user.USER_LOG_NAME = '".addslashes($username)."' OR user.EMAIL_ADDRESS = '".addslashes($username)."') AND user.PASS_USER = '".$password."' AND user.USER_TYPE_ID = $account_login");
				$count = $query->num_rows();
				if($count == 1){
					$userData = $query->row();
					if($userData->USER_STATUS == 'Active'){
						if(isset($userData)){
							$newdata = array(
									'userID'  		=> $userData->USER_ID,
									'adminName'     => $userData->USER_LOG_NAME,
									'userName'      => $userData->USER_NAME,
									'userType'      => $userData->USER_TYPE_ID,
									'roleId'      	=> $userData->ROLE_ID,
									'access'      	=> $userData->ACCESS_TYPE,
									'logged_in' 	=> TRUE
							);
							$this->session->set_userdata($newdata);
						}else{
							$data['MSG'] = '<span style="color:#fff;">System error</span>';
						}
					}else{
						$data['MSG'] = '<span class="error">Your account under review HPP team</span>';
					}
				}else{
					$data['MSG'] = '<span class="error" >User name or password don\'t match</span>';
				}
			}else{
				$data['MSG'] = '<span class="error" >Enter user name and password</span>';
			}
			
		}
		
		
		$userID = $this->session->userData('userID');
		$logged_in = $this->session->userData('logged_in');
		
		if($userID > 0 AND $logged_in == TRUE){
			//$adminName = $this->session->userData('adminName');
			
			redirect(SITE_URL.$page);
			
			$data['main_content']	= $this->load->view('page_templates/dashboard/users/user_home', $data, true);
		}else{
			$data['main_content']	= $this->load->view('page_templates/userLogin/users/login', $data, true);
		}
		
		/**Query for account type**/
		
		
		
		$this->load->view('master', $data);
	}
	
	/*user regiatration logout*/
	public function logoutIndex(){
		$this->session->sess_destroy();
		redirect(SITE_URL.'');			
	}
	
	
	/*user regiatration method*/
	
}

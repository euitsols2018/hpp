<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProfileControll extends HPP_Controller {

    public function __construct(){
		parent::__construct();	
	}
	
	public function profileIndex($id=''){
		$data = array();
		$userID = $this->session->userData('userID');
		$logged_in = $this->session->userData('logged_in');
		$userName = $this->session->userData('userName');
		
		$data['title'] 			= 'Welcome '.$userName.' | HPP';
		
		$data['page'] 			= $this->input->get('page', 'dashborad');
		
		if($userID > 0 AND $logged_in == TRUE){
			
			$data['userName'] 	= $userName;
			$data['userID'] 	= $userID;
			
			
			$data['main_content']	= $this->load->view('page_templates/dashboard/users/user_home', $data, true);
		}else{
			$data['main_content']	= $this->load->view('page_templates/userLogin/users/login', $data, true);
		}
		
		$this->load->view('master', $data);
	}
}
?>
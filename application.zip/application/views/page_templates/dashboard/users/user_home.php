		<div class="page-head"> 
            <div class="container">
                <div class="row">
                    <div class="page-head-content">
                        <h1 class="page-title">Welcome <span class="orange strong"><?= $userName;?></span></h1>               
                    </div>
                </div>
            </div>
        </div>
		<div class="properties-area recent-property" style="">
            <div class="container">  
                <div class="row">
                     
					<div class="col-md-3 p0 padding-top-40 profile_menu_right">
						<div class="blog-asside-right">
							<div class="panel panel-default sidebar-menu wow fadeInRight animated" >
								<div class="panel-heading">
									<h3 class="panel-title">Dashboard</h3>
								</div>
								<?php
								$userType 				= $this->session->userData('userType');
								$roleId 				= $this->session->userData('roleId');
		
								$other_user_type 		= $this->user->any_where(array('TYPE_STATUS' => 'Active', 'TYPE_VIEW' => 'Other'), 'mt_s_user_type');
								$otherTypeID 			= $other_user_type[0]['USER_TYPE_ID'];
								
								$other_role_type 		= $this->user->any_where(array('ROLE_STATUS' => 'Active', 'ROLE_TYPE' => 'Other'), 'mt_s_user_role');
								$otherRoleID 			= $other_role_type[0]['ROLE_ID'];
								
								
								?>
								<div class="panel-body search-widget profile_ul">
									<ul>
										<li><a href="<?= SITE_URL;?>profile/"> Dashboard </a></li>
										<?php
											$pages 		= $this->user->user_pages($otherTypeID,$otherRoleID);
											if(is_array($pages) AND sizeof($pages) > 0){
												foreach($pages AS $info):
												if(($info->PAGE_TYPE == 'Access' OR $info->PAGE_TYPE == 'All_S_B') AND $info->ROLE_ID == $roleId){
												?>
													<li><a href="<?= SITE_URL;?>profile/?page=<?= $info->PAGE_URL;?>"><?= $info->PAGE_NAME;?> </a></li>
												<?php
												}else{
											?>
													<li><a href="<?= SITE_URL;?>profile/?page=<?= $info->PAGE_URL;?>"><?= $info->PAGE_NAME;?></a></li>
											<?php
												}
												endforeach;
											}
										?>
										
									</ul>
								</div>
							</div>

							
						</div>
					</div>

					<div class="col-md-9  pr0 padding-top-40 properties-page">                    
						<div class="col-md-12 clear"> 
							<?php
								if(strlen($page) > 0){
									$page = $page;
								}else{
									$page = 'pages/dashboard';
								}
								$this->load->view('page_templates/dashboard/users/'.$page, '');
							?>
							
						</div>                   
					</div>  
                </div>              
            </div>
        </div>
  
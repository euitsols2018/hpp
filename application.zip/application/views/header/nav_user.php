		<nav class="navbar navbar-default ">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand logo_hpp" href="<?= SITE_URL;?>"><img src="<?= SITE_URL;?>assets/img/logo.png" alt=""></a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse yamm" id="navigation">
                   <div class="button navbar-right">
                       <?php
						$userType = $this->session->userData('userType');
						$navOther = $this->user->any_where(array('NAV_TYPE' => 'RightNav', 'USER_TYPE_ID' => $userType, 'NAV_STATUS' => 'Active'), 'mt_nav_access');
						if(is_array($navOther) AND sizeof($navOther) > 0){
						?>
						
						<a class="navbar-btn nav-button wow fadeInRight join" href="<?= SITE_URL;?><?= $navOther[0]['NAV_URL']?>/" data-wow-delay="0.48s"><?= $navOther[0]['NAV_NAME']?></a>
					   
					   <?php
						}
						$adminName = $this->session->userData('adminName');
					   ?>
					   
					   <a class="navbar-btn nav-button wow login logout_open" data-wow-delay="0.45s" href="<?= SITE_URL;?>logout/"><span class="glyphicon glyphicon-log-out" title="Logout"></span></a>
					   <a class="navbar-btn nav-button wow login login_in_open" data-wow-delay="0.45s" href="<?= SITE_URL;?>profile/"><span class="glyphicon glyphicon-user"  title="Logout"></span></a>
                        
					   
                    </div>
                    <ul class="main-nav nav navbar-nav navbar-right">
                        <li class="dropdown ymm-sw " data-wow-delay="0.1s">
                            <a href="<?= SITE_URL;?>" class="active" data-delay="200">Home </a>
                        </li>

                        <?php
						$navMain = $this->user->any_where(array('NAV_TYPE' => 'Dynamic', 'USER_TYPE_ID' => $userType, 'NAV_STATUS' => 'Active'), 'mt_nav_access');
						$i = 0.2;
						if(is_array($navMain) AND sizeof($navMain) > 0){
							foreach($navMain AS $key=>$value):
						?>
							<li class="wow fadeInDown" data-wow-delay="<?= $i;?>s"><a class="" href="<?= SITE_URL;?><?= $value['NAV_URL']?>/"><?= $value['NAV_NAME']?></a></li>
                        
						<?php
						$i+=0.1;
						endforeach;
						}
					   ?>
					   
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
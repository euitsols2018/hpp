<?php
Class User_model Extends CI_model{
	var $CI;
	public function __construct(){
		parent::__construct();
      	$this->CI =& get_instance();
	
 	}
	public function valitation($valid = array()){
		if(is_array($valid) AND sizeof($valid)){
				$mas = 0;
				$res = '';
			foreach($valid as $key=>$arry){
				
				$then = 0;
				if(is_array($arry) AND sizeof($arry) > 0){
					if($key == 'text'){
						if(array_key_exists('data', $arry)){
							if(array_key_exists('then', $arry)){
								$then = $arry['then'];
							}							
							if(strlen($arry['data']) > $then){
								$mas = 1;								
							}else{
								if(array_key_exists('massage', $arry)){
									$res = $arry['massage'];
								}$mas = 0;						
							}
						}else{
							$res = 'Check invalid for ';$mas = 0;
						}
						break;
					} // end text
					else if($key == 'email'){
						if(array_key_exists('data', $arry)){														
							if(filter_var($arry['data'], FILTER_VALIDATE_EMAIL)){
								$mas = 1;								
							}else{
								if(array_key_exists('massage', $arry)){
									$res = $arry['massage'];
								}$mas = 0;								
							}
						}else{
							$res = 'Check invalid for ';
							$mas = 0;
						}
						break;
					} //end email
					else if($key == 'size'){
						if(array_key_exists('data', $arry)){														
							if(array_key_exists('then', $arry)){
								$then = $arry['then'];
							}
							if(sizeof($arry['data']) > $then){
								$mas = 1;								
							}else{
								if(array_key_exists('massage', $arry)){
									$res = $arry['massage'];
								}$mas = 0;								
							}
						}else{
							$res = 'Check invalid for ';$mas = 0;
						}
						break;
					} //end size
					
					if($mas == 1){
						return 11;
					}else{
						return $res;
					}
				}
			}
		}
	}
	
	
	/**nav bar dynamic**/
	
	public function any_where($query=array(), $table=''){
		if(strlen($table) > 0){
			$this->hpp_table = $table;
		}
		if(is_array($query) AND sizeof($query) > 0){
			$query['COMPANY_ID'] = $this->conpanyID;
			$this->hpp_query = $query;			
		}
		$this->db->where($this->hpp_query);
		$results = $this->db->get($this->hpp_table)->result_array();
		return $results;
	}
	
	public function user_pages($otherTypeID,$otherRoleID){
		$userType 				= $this->session->userData('userType');
		$roleId 				= $this->session->userData('roleId');
		$userID 				= $this->session->userData('userID');						
		$access 				= $this->session->userData('access');						
		
		if($access == 'Parent'){
			$search = "SELECT * 
								FROM
										mt_pg_page_name AS page									
								INNER JOIN 
										mt_s_user_type AS type									
								ON 		page.USER_TYPE_ID = type.USER_TYPE_ID
								INNER JOIN 
										mt_s_user_role AS role									
								ON 		page.ROLE_ID = role.ROLE_ID
								WHERE 	
										(page.USER_TYPE_ID = ".$userType."
										OR page.USER_TYPE_ID = ".$otherTypeID.")
										AND (page.ROLE_ID = ".$roleId."
										OR page.ROLE_ID = ".$otherRoleID.")
										AND page.PAGE_STATUS = 'Active'
										AND page.COMPANY_ID = ".$this->conpanyID."
						";
						
		}else{
			
			$search = "SELECT * 
								FROM
										mt_pg_page_name AS page									
								INNER JOIN 
										mt_pg_page_access AS access									
								ON 		page.PAGE_ID = access.PAGE_ID AND access.USER_ID = ".$userID."
								WHERE
										page.COMPANY_ID = ".$this->conpanyID."
										AND page.PAGE_STATUS = 'Active'
						";
						
		}
		$query = $this->db->query($search);
		$count = $query->num_rows();
		if($count > 0){
			return $query->result();			
		}else{
			return array();
		}
	}
	
	/** start select**/
	public function create_select($data = array(), $value='', $print='', $check='0'){
		if(sizeof($data) > 0){
			$res = '';
			foreach($data as $val){
				if($val[$value] == $check){
					$res .= '<option value="'.$val[$value].'" selected> '.$val[$print].' </option>';
				}else{
					$res .= '<option value="'.$val[$value].'"> '.$val[$print].' </option>';
				}
				
			}
			return $res;
		}
	}
	
	
	public function property_fileld($typeid='0'){
		if($typeid > 0){
			$search = "SELECT * 
								FROM 
										mt_p_pro_add_fixed_filed_set AS filed
								INNER JOIN
										mt_p_property_additional_filed AS addi
								ON 
										filed.ADD_FILED_ID = addi.ADD_FILED_ID
										AND filed.COMPANY_ID = addi.COMPANY_ID
								WHERE
										filed.PROPERTY_TYPE_ID = ".$typeid."
										AND filed.COMPANY_ID = ".$this->conpanyID."
										AND addi.COMPANY_ID = ".$this->conpanyID."
										AND filed.ACCESS_STATUS = 'Active'
										
						
						";
			$query = $this->db->query($search);
			return $query->result();
		}
		
	}
	
	
	public function create_filed($type='TEXT', $id="filed", $name='No name', $value='', $extra=''){
		if($type == 'textarea'){
			return ' <textarea name="'.$id.'" id="'.$id.'" class="form-control" '.$extra.'> '.$value.' </textarea>';
		}else if($type == 'radio' OR $type == 'checkbox'){
			return ' <input name="'.$id.'" id="'.$id.'" type="'.$type.'" class="form-control" value="'.$value.'" '.$extra.'> '.$name.' ';
		}else if($type == 'number'){
			return ' <input name="'.$id.'" id="'.$id.'" type="number" class="form-control" placeholder="" min="1" step="1" value="'.$value.'" onkeyup="removeChar(this);" '.$extra.' >';
		}else{
			return ' <input name="'.$id.'" id="'.$id.'" type="'.$type.'" class="form-control" placeholder="" value="'.$value.'" '.$extra.'>';
		}
	}
	
}
?>
-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 01, 2018 at 08:27 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `realstate`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `COMPANY_ID` mediumint(9) NOT NULL,
  `COMPANY_NAME` mediumtext NOT NULL,
  `BUSINESS_DATE` date NOT NULL DEFAULT '0000-00-00',
  `ENT_DATE` date NOT NULL DEFAULT '0000-00-00',
  `COMPANY_STATUS` enum('Active','DeActive') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`COMPANY_ID`, `COMPANY_NAME`, `BUSINESS_DATE`, `ENT_DATE`, `COMPANY_STATUS`) VALUES
(1, 'Hot Price Property', '2017-12-21', '2017-12-18', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `c_contact_info`
--

CREATE TABLE `c_contact_info` (
  `CONTACT_ID` mediumint(9) NOT NULL,
  `CONTACT_NAME` mediumtext NOT NULL,
  `CONTACT_TYPE_ID` mediumint(9) NOT NULL,
  `USER_ID` mediumint(9) NOT NULL,
  `COMPANY_ID` mediumint(9) NOT NULL,
  `ENT_DATE` date DEFAULT '0000-00-00',
  `CONTACT_STATUS` enum('Active','DeActive') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c_contact_info`
--

INSERT INTO `c_contact_info` (`CONTACT_ID`, `CONTACT_NAME`, `CONTACT_TYPE_ID`, `USER_ID`, `COMPANY_ID`, `ENT_DATE`, `CONTACT_STATUS`) VALUES
(1, '01734697406', 4, 1, 1, '0000-00-00', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `mt_c_contact_type`
--

CREATE TABLE `mt_c_contact_type` (
  `CONTACT_TYPE_ID` mediumint(9) NOT NULL,
  `CONTACT_NAME` mediumtext NOT NULL,
  `CONTACT_TYPE_ICON` mediumtext NOT NULL,
  `CONTACT_TYPE_URL` mediumtext NOT NULL,
  `CONTAC_TYPE_TYPE` enum('Basic','Social') DEFAULT 'Basic',
  `COMPANY_ID` mediumint(9) NOT NULL,
  `CONTACT_TYPE_STATUS` enum('Active','DeActive') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mt_c_contact_type`
--

INSERT INTO `mt_c_contact_type` (`CONTACT_TYPE_ID`, `CONTACT_NAME`, `CONTACT_TYPE_ICON`, `CONTACT_TYPE_URL`, `CONTAC_TYPE_TYPE`, `COMPANY_ID`, `CONTACT_TYPE_STATUS`) VALUES
(1, 'Facebook', 'fa fa-facebook', 'https://www.facebook.com', 'Social', 1, 'Active'),
(2, 'Google +', 'fa fa-google-plus', 'https://www.plus.google.com', 'Social', 1, 'Active'),
(3, 'Phone', 'fa fa-phone', '#', 'Basic', 1, 'Active'),
(4, 'Mobile', 'fa fa-mobile', '#', 'Basic', 1, 'Active'),
(5, 'Twitter', 'fa fa-twitter', 'https://www.twitter.com', 'Social', 1, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `mt_pg_page_access`
--

CREATE TABLE `mt_pg_page_access` (
  `ACCESS_ID` mediumint(9) NOT NULL,
  `PAGE_ID` mediumint(9) NOT NULL,
  `COMPANY_ID` mediumint(9) NOT NULL,
  `USER_ID` mediumint(9) NOT NULL,
  `ENT_USER` mediumint(9) NOT NULL,
  `ACCESS_STATUS` enum('Active','DeActive') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mt_pg_page_access`
--

INSERT INTO `mt_pg_page_access` (`ACCESS_ID`, `PAGE_ID`, `COMPANY_ID`, `USER_ID`, `ENT_USER`, `ACCESS_STATUS`) VALUES
(1, 2, 1, 1, 2, 'Active'),
(2, 2, 1, 1, 2, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `mt_pg_page_name`
--

CREATE TABLE `mt_pg_page_name` (
  `PAGE_ID` mediumint(9) NOT NULL,
  `PAGE_NAME` mediumtext NOT NULL,
  `PAGE_URL` mediumtext NOT NULL,
  `PAGE_TYPE` enum('Default','Access') DEFAULT NULL,
  `PAGE_USER_TYPE` enum('All','Super','Admin','Personal','Company') DEFAULT 'All',
  `COMPANY_ID` mediumint(9) NOT NULL,
  `PAGE_STATUS` enum('Active','DeActive') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mt_pg_page_name`
--

INSERT INTO `mt_pg_page_name` (`PAGE_ID`, `PAGE_NAME`, `PAGE_URL`, `PAGE_TYPE`, `PAGE_USER_TYPE`, `COMPANY_ID`, `PAGE_STATUS`) VALUES
(1, 'Dashboard', 'dashboard', 'Default', 'All', 1, 'Active'),
(2, 'Manage Admin', 'manage_admin', 'Default', 'Super', 1, 'Active'),
(3, 'Add Admin', 'add_admin', 'Default', 'Super', 1, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `mt_p_property_additional_filed`
--

CREATE TABLE `mt_p_property_additional_filed` (
  `ADD_FILED_ID` mediumint(9) NOT NULL,
  `FILED_NAME` mediumtext NOT NULL,
  `FILED_ID_NAME` mediumtext,
  `FILED_TYPE` enum('TEXT','TEXTAREA','SELECT','RADIO','CHECKBOX','DATE') DEFAULT NULL,
  `FILED_HTML` mediumtext NOT NULL,
  `COMPANY_ID` mediumint(9) NOT NULL,
  `FILED_STATUS` enum('Active','DeActive') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mt_p_property_additional_filed`
--

INSERT INTO `mt_p_property_additional_filed` (`ADD_FILED_ID`, `FILED_NAME`, `FILED_ID_NAME`, `FILED_TYPE`, `FILED_HTML`, `COMPANY_ID`, `FILED_STATUS`) VALUES
(1, 'Number of Bedrooms', 'BEDROOMS', 'TEXT', '', 1, 'Active'),
(2, 'Number of Bathrooms', 'BATHROOMS', 'TEXT', '', 1, 'Active'),
(3, 'Kitchen room', 'KITCHEN', 'TEXT', '', 1, 'Active'),
(4, 'Area of property', 'AREA', 'TEXT', '', 1, 'Active'),
(5, 'Washroom', 'WASHROOM', 'TEXT', '', 1, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `mt_p_property_category`
--

CREATE TABLE `mt_p_property_category` (
  `PRO_CATEGORY_ID` mediumint(9) NOT NULL,
  `PRO_CATEGORY_NAME` mediumtext NOT NULL,
  `BUYER_FILED` mediumtext,
  `SELLER_FILED` mediumtext,
  `COMPANY_ID` mediumint(9) NOT NULL,
  `PRO_CATEGORY_STATUS` enum('Active','DeActive') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mt_p_property_category`
--

INSERT INTO `mt_p_property_category` (`PRO_CATEGORY_ID`, `PRO_CATEGORY_NAME`, `BUYER_FILED`, `SELLER_FILED`, `COMPANY_ID`, `PRO_CATEGORY_STATUS`) VALUES
(1, 'Buy', 'Buying', 'Selling', 1, 'Active'),
(2, 'Rent', 'Renter', 'Rent', 1, 'Active'),
(3, 'House Share', 'House Sharing', 'House Share', 1, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `mt_p_property_type`
--

CREATE TABLE `mt_p_property_type` (
  `PROPERTY_TYPE_ID` mediumint(9) NOT NULL,
  `PROPERTY_TYPE_NAME` mediumtext NOT NULL,
  `COMPANY_ID` mediumint(9) NOT NULL,
  `PROPERTY_TYPE_STATUS` enum('Active','DeActive') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mt_p_property_type`
--

INSERT INTO `mt_p_property_type` (`PROPERTY_TYPE_ID`, `PROPERTY_TYPE_NAME`, `COMPANY_ID`, `PROPERTY_TYPE_STATUS`) VALUES
(1, 'Flat', 1, 'Active'),
(2, 'House', 1, 'Active'),
(3, 'Land', 1, 'Active'),
(4, 'Office', 1, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `mt_p_pro_add_fixed_filed_set`
--

CREATE TABLE `mt_p_pro_add_fixed_filed_set` (
  `ACCESS_FILED_ID` mediumint(9) NOT NULL,
  `ADD_FILED_ID` mediumint(9) NOT NULL,
  `PROPERTY_TYPE_ID` mediumint(9) NOT NULL,
  `COMPANY_ID` mediumint(9) NOT NULL,
  `ACCESS_STATUS` enum('Active','DeActive') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mt_p_pro_add_fixed_filed_set`
--

INSERT INTO `mt_p_pro_add_fixed_filed_set` (`ACCESS_FILED_ID`, `ADD_FILED_ID`, `PROPERTY_TYPE_ID`, `COMPANY_ID`, `ACCESS_STATUS`) VALUES
(1, 1, 1, 1, 'Active'),
(2, 2, 1, 1, 'Active'),
(3, 3, 1, 1, 'Active'),
(4, 4, 1, 1, 'Active'),
(5, 5, 1, 1, 'Active'),
(6, 4, 2, 1, 'Active'),
(7, 4, 3, 1, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `mt_p_video_type`
--

CREATE TABLE `mt_p_video_type` (
  `VIDEO_TYPE_ID` mediumint(9) NOT NULL,
  `TYPE_NAME` mediumtext NOT NULL,
  `EMBED_URL` mediumtext NOT NULL,
  `COMPANY_ID` mediumint(9) NOT NULL,
  `TYPE_STATUS` enum('Active','DeActive') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mt_p_video_type`
--

INSERT INTO `mt_p_video_type` (`VIDEO_TYPE_ID`, `TYPE_NAME`, `EMBED_URL`, `COMPANY_ID`, `TYPE_STATUS`) VALUES
(1, 'Youtube', 'https://www.youtube.com/embed/', 1, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `mt_s_user_role`
--

CREATE TABLE `mt_s_user_role` (
  `ROLE_ID` mediumint(9) NOT NULL,
  `ROLE_NAME` mediumtext NOT NULL,
  `ROLE_TYPE` enum('Admin','User') DEFAULT NULL,
  `ROLE_STATUS` enum('Active','DeActive') DEFAULT NULL,
  `COMPANY_ID` mediumint(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mt_s_user_role`
--

INSERT INTO `mt_s_user_role` (`ROLE_ID`, `ROLE_NAME`, `ROLE_TYPE`, `ROLE_STATUS`, `COMPANY_ID`) VALUES
(1, 'Admin', 'Admin', 'Active', 1),
(2, 'Super Admin', 'Admin', 'Active', 1),
(3, 'Personal', 'User', 'Active', 1),
(4, 'Company', 'User', 'Active', 1),
(5, 'Account', 'Admin', 'Active', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mt_s_user_type`
--

CREATE TABLE `mt_s_user_type` (
  `USER_TYPE_ID` mediumint(9) NOT NULL,
  `TYPE_NAME` mediumtext NOT NULL,
  `COMPANY_ID` mediumint(9) NOT NULL,
  `TYPE_STATUS` enum('Active','DeActive') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mt_s_user_type`
--

INSERT INTO `mt_s_user_type` (`USER_TYPE_ID`, `TYPE_NAME`, `COMPANY_ID`, `TYPE_STATUS`) VALUES
(1, 'Seller', 1, 'Active'),
(2, 'Buyer', 1, 'Active'),
(3, 'Other', 1, 'DeActive');

-- --------------------------------------------------------

--
-- Table structure for table `p_property_additional`
--

CREATE TABLE `p_property_additional` (
  `ADD_FILED_P_ID` mediumint(9) NOT NULL,
  `ADD_FILED_ID` mediumint(9) NOT NULL,
  `PROPERTY_ID` mediumint(9) NOT NULL,
  `FILED_DATA` mediumtext NOT NULL,
  `FILED_OTHERS` mediumtext NOT NULL,
  `COMPANY_ID` mediumint(9) NOT NULL,
  `USER_ID` mediumint(9) NOT NULL,
  `ENT_DATE` date DEFAULT '0000-00-00',
  `FILED_STATUS` enum('Active','DeActive') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `p_property_basic`
--

CREATE TABLE `p_property_basic` (
  `PROPERTY_ID` mediumint(9) NOT NULL,
  `PROPERTY_NAME` mediumtext NOT NULL,
  `PRO_CATEGORY_ID` mediumint(9) NOT NULL,
  `PROPERTY_TYPE_ID` mediumint(9) NOT NULL,
  `PROPERTY_PRICE` mediumint(9) NOT NULL,
  `PROPERTY_DESCRIPTION` longtext NOT NULL,
  `COMPANY_ID` mediumint(9) NOT NULL,
  `USER_ID` mediumint(9) NOT NULL,
  `ENT_DATE` date DEFAULT '0000-00-00',
  `PROPERTY_STATUS` enum('Active','DeActive','Pending') DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `p_property_images`
--

CREATE TABLE `p_property_images` (
  `IMAGE_ID` mediumint(9) NOT NULL,
  `IMAGE_NAME` mediumtext NOT NULL,
  `IMAGE_LINK` mediumtext NOT NULL,
  `PROPERTY_ID` mediumint(9) NOT NULL,
  `IMAGE_DESCRIPTION` longtext NOT NULL,
  `COMPANY_ID` mediumint(9) NOT NULL,
  `USER_ID` mediumint(9) NOT NULL,
  `ENT_DATE` date DEFAULT '0000-00-00',
  `IMAGE_STATUS` enum('Active','DeActive') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `p_property_offers`
--

CREATE TABLE `p_property_offers` (
  `OFFER_P_ID` mediumint(9) NOT NULL,
  `OFFER_PRICE` mediumint(9) NOT NULL,
  `OFFER_DETAILS` mediumtext NOT NULL,
  `OFFER_TYPE` enum('Bid','Dis') DEFAULT 'Dis',
  `PROPERTY_ID` mediumint(9) NOT NULL,
  `COMPANY_ID` mediumint(9) NOT NULL,
  `USER_ID` mediumint(9) NOT NULL,
  `ENT_DATE` date DEFAULT '0000-00-00',
  `OFFER_STATUS` enum('Active','DeActive') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `p_property_offers_bidding`
--

CREATE TABLE `p_property_offers_bidding` (
  `OFFER_BID_ID` mediumint(9) NOT NULL,
  `OFFER_BID_PRICE` mediumint(9) NOT NULL,
  `OFFER_BID_DETAILS` mediumtext NOT NULL,
  `PROPERTY_ID` mediumint(9) NOT NULL,
  `OFFER_P_ID` mediumint(9) NOT NULL,
  `COMPANY_ID` mediumint(9) NOT NULL,
  `USER_ID` mediumint(9) NOT NULL,
  `ENT_DATE` date DEFAULT '0000-00-00',
  `OFFER_BID_STATUS` enum('Active','DeActive') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `p_property_videos`
--

CREATE TABLE `p_property_videos` (
  `VIDEOS_ID` mediumint(9) NOT NULL,
  `VIDEOS_NAME` mediumtext NOT NULL,
  `VIDEOS_LINK` mediumtext NOT NULL,
  `PROPERTY_ID` mediumint(9) NOT NULL,
  `VIDEO_TYPE_ID` mediumint(9) NOT NULL,
  `VIDEOS_DESCRIPTION` longtext NOT NULL,
  `COMPANY_ID` mediumint(9) NOT NULL,
  `USER_ID` mediumint(9) NOT NULL,
  `ENT_DATE` date DEFAULT '0000-00-00',
  `VIDEOS_STATUS` enum('Active','DeActive') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `s_user_details_info`
--

CREATE TABLE `s_user_details_info` (
  `USER_DETAILS_ID` mediumint(9) NOT NULL,
  `FULL_NAME` mediumtext NOT NULL,
  `SUB_NAME` mediumtext NOT NULL,
  `GENTER` enum('Male','FeMale','Common') NOT NULL,
  `OVERVIEW` mediumtext NOT NULL,
  `ADDRESS` mediumtext NOT NULL,
  `USER_ID` mediumint(9) NOT NULL,
  `COMPANY_ID` mediumint(9) NOT NULL,
  `ENT_DATE` date DEFAULT '0000-00-00',
  `DETAILS_STATUS` enum('Active','DeActive') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `s_user_details_info`
--

INSERT INTO `s_user_details_info` (`USER_DETAILS_ID`, `FULL_NAME`, `SUB_NAME`, `GENTER`, `OVERVIEW`, `ADDRESS`, `USER_ID`, `COMPANY_ID`, `ENT_DATE`, `DETAILS_STATUS`) VALUES
(1, 'Hot price property LTD.', 'Real State company', 'Male', 'basic skills ...', 'mirpur 10, Dhaka, Bangladesh', 1, 1, '0000-00-00', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `s_user_info`
--

CREATE TABLE `s_user_info` (
  `USER_ID` mediumint(9) NOT NULL,
  `USER_NAME` tinytext NOT NULL,
  `USER_LOG_NAME` tinytext NOT NULL,
  `EMAIL_ADDRESS` mediumtext NOT NULL,
  `PASS_USER` tinytext NOT NULL,
  `COMPANY_ID` mediumint(9) NOT NULL,
  `ROLE_ID` mediumint(9) NOT NULL,
  `USER_TYPE_ID` mediumint(9) NOT NULL,
  `ENT_DATE` date DEFAULT '0000-00-00',
  `USER_STATUS` enum('Active','Pending','DeActive','Disable') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `s_user_info`
--

INSERT INTO `s_user_info` (`USER_ID`, `USER_NAME`, `USER_LOG_NAME`, `EMAIL_ADDRESS`, `PASS_USER`, `COMPANY_ID`, `ROLE_ID`, `USER_TYPE_ID`, `ENT_DATE`, `USER_STATUS`) VALUES
(1, 'Super Admin', 'super', 'superadmin@gmail.com', '123456', 1, 2, 2, '0000-00-00', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`COMPANY_ID`);

--
-- Indexes for table `c_contact_info`
--
ALTER TABLE `c_contact_info`
  ADD PRIMARY KEY (`CONTACT_ID`),
  ADD KEY `USER_ID` (`USER_ID`),
  ADD KEY `CONTACT_TYPE_ID` (`CONTACT_TYPE_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`);

--
-- Indexes for table `mt_c_contact_type`
--
ALTER TABLE `mt_c_contact_type`
  ADD PRIMARY KEY (`CONTACT_TYPE_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`);

--
-- Indexes for table `mt_pg_page_access`
--
ALTER TABLE `mt_pg_page_access`
  ADD PRIMARY KEY (`ACCESS_ID`),
  ADD KEY `PAGE_ID` (`PAGE_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`),
  ADD KEY `USER_ID` (`USER_ID`);

--
-- Indexes for table `mt_pg_page_name`
--
ALTER TABLE `mt_pg_page_name`
  ADD PRIMARY KEY (`PAGE_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`);

--
-- Indexes for table `mt_p_property_additional_filed`
--
ALTER TABLE `mt_p_property_additional_filed`
  ADD PRIMARY KEY (`ADD_FILED_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`);

--
-- Indexes for table `mt_p_property_category`
--
ALTER TABLE `mt_p_property_category`
  ADD PRIMARY KEY (`PRO_CATEGORY_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`);

--
-- Indexes for table `mt_p_property_type`
--
ALTER TABLE `mt_p_property_type`
  ADD PRIMARY KEY (`PROPERTY_TYPE_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`);

--
-- Indexes for table `mt_p_pro_add_fixed_filed_set`
--
ALTER TABLE `mt_p_pro_add_fixed_filed_set`
  ADD PRIMARY KEY (`ACCESS_FILED_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`),
  ADD KEY `PROPERTY_TYPE_ID` (`PROPERTY_TYPE_ID`),
  ADD KEY `ADD_FILED_ID` (`ADD_FILED_ID`);

--
-- Indexes for table `mt_p_video_type`
--
ALTER TABLE `mt_p_video_type`
  ADD PRIMARY KEY (`VIDEO_TYPE_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`);

--
-- Indexes for table `mt_s_user_role`
--
ALTER TABLE `mt_s_user_role`
  ADD PRIMARY KEY (`ROLE_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`);

--
-- Indexes for table `mt_s_user_type`
--
ALTER TABLE `mt_s_user_type`
  ADD PRIMARY KEY (`USER_TYPE_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`);

--
-- Indexes for table `p_property_additional`
--
ALTER TABLE `p_property_additional`
  ADD PRIMARY KEY (`ADD_FILED_P_ID`),
  ADD KEY `ADD_FILED_ID` (`ADD_FILED_ID`),
  ADD KEY `PROPERTY_ID` (`PROPERTY_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`),
  ADD KEY `USER_ID` (`USER_ID`);

--
-- Indexes for table `p_property_basic`
--
ALTER TABLE `p_property_basic`
  ADD PRIMARY KEY (`PROPERTY_ID`),
  ADD KEY `PRO_CATEGORY_ID` (`PRO_CATEGORY_ID`),
  ADD KEY `PROPERTY_TYPE_ID` (`PROPERTY_TYPE_ID`),
  ADD KEY `USER_ID` (`USER_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`);

--
-- Indexes for table `p_property_images`
--
ALTER TABLE `p_property_images`
  ADD PRIMARY KEY (`IMAGE_ID`),
  ADD KEY `PROPERTY_ID` (`PROPERTY_ID`),
  ADD KEY `USER_ID` (`USER_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`);

--
-- Indexes for table `p_property_offers`
--
ALTER TABLE `p_property_offers`
  ADD PRIMARY KEY (`OFFER_P_ID`),
  ADD KEY `PROPERTY_ID` (`PROPERTY_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`),
  ADD KEY `USER_ID` (`USER_ID`);

--
-- Indexes for table `p_property_offers_bidding`
--
ALTER TABLE `p_property_offers_bidding`
  ADD PRIMARY KEY (`OFFER_BID_ID`),
  ADD KEY `PROPERTY_ID` (`PROPERTY_ID`),
  ADD KEY `OFFER_P_ID` (`OFFER_P_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`),
  ADD KEY `USER_ID` (`USER_ID`);

--
-- Indexes for table `p_property_videos`
--
ALTER TABLE `p_property_videos`
  ADD PRIMARY KEY (`VIDEOS_ID`),
  ADD KEY `USER_ID` (`USER_ID`),
  ADD KEY `VIDEO_TYPE_ID` (`VIDEO_TYPE_ID`),
  ADD KEY `PROPERTY_ID` (`PROPERTY_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`);

--
-- Indexes for table `s_user_details_info`
--
ALTER TABLE `s_user_details_info`
  ADD PRIMARY KEY (`USER_DETAILS_ID`),
  ADD KEY `USER_ID` (`USER_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`);

--
-- Indexes for table `s_user_info`
--
ALTER TABLE `s_user_info`
  ADD PRIMARY KEY (`USER_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`),
  ADD KEY `ROLE_ID` (`ROLE_ID`),
  ADD KEY `USER_TYPE_ID` (`USER_TYPE_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `COMPANY_ID` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `c_contact_info`
--
ALTER TABLE `c_contact_info`
  MODIFY `CONTACT_ID` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mt_c_contact_type`
--
ALTER TABLE `mt_c_contact_type`
  MODIFY `CONTACT_TYPE_ID` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `mt_pg_page_access`
--
ALTER TABLE `mt_pg_page_access`
  MODIFY `ACCESS_ID` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mt_pg_page_name`
--
ALTER TABLE `mt_pg_page_name`
  MODIFY `PAGE_ID` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mt_p_property_additional_filed`
--
ALTER TABLE `mt_p_property_additional_filed`
  MODIFY `ADD_FILED_ID` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `mt_p_property_category`
--
ALTER TABLE `mt_p_property_category`
  MODIFY `PRO_CATEGORY_ID` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mt_p_property_type`
--
ALTER TABLE `mt_p_property_type`
  MODIFY `PROPERTY_TYPE_ID` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `mt_p_pro_add_fixed_filed_set`
--
ALTER TABLE `mt_p_pro_add_fixed_filed_set`
  MODIFY `ACCESS_FILED_ID` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `mt_p_video_type`
--
ALTER TABLE `mt_p_video_type`
  MODIFY `VIDEO_TYPE_ID` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mt_s_user_role`
--
ALTER TABLE `mt_s_user_role`
  MODIFY `ROLE_ID` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `mt_s_user_type`
--
ALTER TABLE `mt_s_user_type`
  MODIFY `USER_TYPE_ID` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `p_property_additional`
--
ALTER TABLE `p_property_additional`
  MODIFY `ADD_FILED_P_ID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `p_property_basic`
--
ALTER TABLE `p_property_basic`
  MODIFY `PROPERTY_ID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `p_property_images`
--
ALTER TABLE `p_property_images`
  MODIFY `IMAGE_ID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `p_property_offers`
--
ALTER TABLE `p_property_offers`
  MODIFY `OFFER_P_ID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `p_property_offers_bidding`
--
ALTER TABLE `p_property_offers_bidding`
  MODIFY `OFFER_BID_ID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `p_property_videos`
--
ALTER TABLE `p_property_videos`
  MODIFY `VIDEOS_ID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `s_user_details_info`
--
ALTER TABLE `s_user_details_info`
  MODIFY `USER_DETAILS_ID` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `s_user_info`
--
ALTER TABLE `s_user_info`
  MODIFY `USER_ID` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `c_contact_info`
--
ALTER TABLE `c_contact_info`
  ADD CONSTRAINT `c_contact_info_ibfk_1` FOREIGN KEY (`USER_ID`) REFERENCES `s_user_info` (`USER_ID`),
  ADD CONSTRAINT `c_contact_info_ibfk_2` FOREIGN KEY (`CONTACT_TYPE_ID`) REFERENCES `mt_c_contact_type` (`CONTACT_TYPE_ID`),
  ADD CONSTRAINT `c_contact_info_ibfk_3` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`);

--
-- Constraints for table `mt_c_contact_type`
--
ALTER TABLE `mt_c_contact_type`
  ADD CONSTRAINT `mt_c_contact_type_ibfk_1` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`);

--
-- Constraints for table `mt_pg_page_access`
--
ALTER TABLE `mt_pg_page_access`
  ADD CONSTRAINT `mt_pg_page_access_ibfk_1` FOREIGN KEY (`PAGE_ID`) REFERENCES `mt_pg_page_name` (`PAGE_ID`),
  ADD CONSTRAINT `mt_pg_page_access_ibfk_2` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`),
  ADD CONSTRAINT `mt_pg_page_access_ibfk_3` FOREIGN KEY (`USER_ID`) REFERENCES `s_user_info` (`USER_ID`);

--
-- Constraints for table `mt_pg_page_name`
--
ALTER TABLE `mt_pg_page_name`
  ADD CONSTRAINT `mt_pg_page_name_ibfk_2` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`);

--
-- Constraints for table `mt_p_property_additional_filed`
--
ALTER TABLE `mt_p_property_additional_filed`
  ADD CONSTRAINT `hj` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`);

--
-- Constraints for table `mt_p_property_category`
--
ALTER TABLE `mt_p_property_category`
  ADD CONSTRAINT `mt_p_property_category_ibfk_1` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`);

--
-- Constraints for table `mt_p_property_type`
--
ALTER TABLE `mt_p_property_type`
  ADD CONSTRAINT `mt_p_property_type_ibfk_1` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`);

--
-- Constraints for table `mt_p_pro_add_fixed_filed_set`
--
ALTER TABLE `mt_p_pro_add_fixed_filed_set`
  ADD CONSTRAINT `mt_p_pro_add_fixed_filed_set_ibfk_1` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`),
  ADD CONSTRAINT `mt_p_pro_add_fixed_filed_set_ibfk_2` FOREIGN KEY (`PROPERTY_TYPE_ID`) REFERENCES `mt_p_property_type` (`PROPERTY_TYPE_ID`),
  ADD CONSTRAINT `mt_p_pro_add_fixed_filed_set_ibfk_3` FOREIGN KEY (`ADD_FILED_ID`) REFERENCES `mt_p_property_additional_filed` (`ADD_FILED_ID`);

--
-- Constraints for table `mt_p_video_type`
--
ALTER TABLE `mt_p_video_type`
  ADD CONSTRAINT `mt_p_video_type_ibfk_1` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`);

--
-- Constraints for table `mt_s_user_role`
--
ALTER TABLE `mt_s_user_role`
  ADD CONSTRAINT `mt_s_user_role_ibfk_1` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`);

--
-- Constraints for table `mt_s_user_type`
--
ALTER TABLE `mt_s_user_type`
  ADD CONSTRAINT `mt_s_user_type_ibfk_1` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`);

--
-- Constraints for table `p_property_additional`
--
ALTER TABLE `p_property_additional`
  ADD CONSTRAINT `p_property_additional_ibfk_1` FOREIGN KEY (`ADD_FILED_ID`) REFERENCES `mt_p_property_additional_filed` (`ADD_FILED_ID`),
  ADD CONSTRAINT `p_property_additional_ibfk_2` FOREIGN KEY (`PROPERTY_ID`) REFERENCES `p_property_basic` (`PROPERTY_ID`),
  ADD CONSTRAINT `p_property_additional_ibfk_3` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`),
  ADD CONSTRAINT `p_property_additional_ibfk_4` FOREIGN KEY (`USER_ID`) REFERENCES `s_user_info` (`USER_ID`);

--
-- Constraints for table `p_property_basic`
--
ALTER TABLE `p_property_basic`
  ADD CONSTRAINT `p_property_basic_ibfk_1` FOREIGN KEY (`PRO_CATEGORY_ID`) REFERENCES `mt_p_property_category` (`PRO_CATEGORY_ID`),
  ADD CONSTRAINT `p_property_basic_ibfk_2` FOREIGN KEY (`PROPERTY_TYPE_ID`) REFERENCES `mt_p_property_type` (`PROPERTY_TYPE_ID`),
  ADD CONSTRAINT `p_property_basic_ibfk_3` FOREIGN KEY (`USER_ID`) REFERENCES `s_user_info` (`USER_ID`),
  ADD CONSTRAINT `p_property_basic_ibfk_4` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`);

--
-- Constraints for table `p_property_images`
--
ALTER TABLE `p_property_images`
  ADD CONSTRAINT `p_property_images_ibfk_1` FOREIGN KEY (`PROPERTY_ID`) REFERENCES `p_property_basic` (`PROPERTY_ID`),
  ADD CONSTRAINT `p_property_images_ibfk_2` FOREIGN KEY (`USER_ID`) REFERENCES `s_user_info` (`USER_ID`),
  ADD CONSTRAINT `p_property_images_ibfk_3` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`);

--
-- Constraints for table `p_property_offers`
--
ALTER TABLE `p_property_offers`
  ADD CONSTRAINT `p_property_offers_ibfk_1` FOREIGN KEY (`PROPERTY_ID`) REFERENCES `p_property_basic` (`PROPERTY_ID`),
  ADD CONSTRAINT `p_property_offers_ibfk_2` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`),
  ADD CONSTRAINT `p_property_offers_ibfk_3` FOREIGN KEY (`USER_ID`) REFERENCES `s_user_info` (`USER_ID`);

--
-- Constraints for table `p_property_offers_bidding`
--
ALTER TABLE `p_property_offers_bidding`
  ADD CONSTRAINT `p_property_offers_bidding_ibfk_1` FOREIGN KEY (`PROPERTY_ID`) REFERENCES `p_property_basic` (`PROPERTY_ID`),
  ADD CONSTRAINT `p_property_offers_bidding_ibfk_2` FOREIGN KEY (`OFFER_P_ID`) REFERENCES `p_property_offers` (`OFFER_P_ID`),
  ADD CONSTRAINT `p_property_offers_bidding_ibfk_3` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`),
  ADD CONSTRAINT `p_property_offers_bidding_ibfk_4` FOREIGN KEY (`USER_ID`) REFERENCES `s_user_info` (`USER_ID`);

--
-- Constraints for table `p_property_videos`
--
ALTER TABLE `p_property_videos`
  ADD CONSTRAINT `p_property_videos_ibfk_1` FOREIGN KEY (`USER_ID`) REFERENCES `s_user_info` (`USER_ID`),
  ADD CONSTRAINT `p_property_videos_ibfk_2` FOREIGN KEY (`VIDEO_TYPE_ID`) REFERENCES `mt_p_video_type` (`VIDEO_TYPE_ID`),
  ADD CONSTRAINT `p_property_videos_ibfk_3` FOREIGN KEY (`PROPERTY_ID`) REFERENCES `p_property_basic` (`PROPERTY_ID`),
  ADD CONSTRAINT `p_property_videos_ibfk_4` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`);

--
-- Constraints for table `s_user_details_info`
--
ALTER TABLE `s_user_details_info`
  ADD CONSTRAINT `s_user_details_info_ibfk_1` FOREIGN KEY (`USER_ID`) REFERENCES `s_user_info` (`USER_ID`),
  ADD CONSTRAINT `s_user_details_info_ibfk_2` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`);

--
-- Constraints for table `s_user_info`
--
ALTER TABLE `s_user_info`
  ADD CONSTRAINT `s_user_info_ibfk_1` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`),
  ADD CONSTRAINT `s_user_info_ibfk_2` FOREIGN KEY (`ROLE_ID`) REFERENCES `mt_s_user_role` (`ROLE_ID`),
  ADD CONSTRAINT `s_user_info_ibfk_3` FOREIGN KEY (`USER_TYPE_ID`) REFERENCES `mt_s_user_type` (`USER_TYPE_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
